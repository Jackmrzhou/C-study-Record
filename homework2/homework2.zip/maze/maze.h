#ifndef _MAZE_H
#define _MAZE_H

typedef struct STRUCT_MAZE{
    int map[10][10];
    int out_X;
    int out_Y;
}MAZE;

#endif