#ifndef _DRAW_H
#define _DRAW_H

void draw(MAZE *maze,link_array *success_path)
#endif